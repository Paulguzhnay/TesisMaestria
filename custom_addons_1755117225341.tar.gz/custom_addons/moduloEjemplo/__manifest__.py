{
    'name': 'Mi Módulo Ejemplo',
    'version': '1.0',
    'category': 'Custom',
    'summary': 'Un módulo personalizado de ejemplo',
    'author': 'Paul',
    'depends': ['base'],
    'data': [],
    'installable': True,
    'application': True,
}
