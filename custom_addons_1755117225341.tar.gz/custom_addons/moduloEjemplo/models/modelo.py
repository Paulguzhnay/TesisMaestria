from odoo import models, fields

class MiModeloEjemplo(models.Model):
    _name = 'mi.modelo.ejemplo'
    _description = 'Modelo Ejemplo'

    name = fields.Char(string='Nombre')
